def analyze_and_transfer_emotion(source_audio_path, target_audio_path, output_path):
    """
    Analyze emotional characteristics of source audio and transfer to target audio.
    """
    import librosa
    import numpy as np
    import soundfile as sf
    from scipy.signal import savgol_filter
    
    # Load audio files
    y_source, sr_source = librosa.load(source_audio_path, sr=None)
    y_target, sr_target = librosa.load(target_audio_path, sr=None)
    
    # Extract pitch contour from source
    source_pitch, _ = librosa.piptrack(y=y_source, sr=sr_source)
    source_pitch_median = np.median(source_pitch[source_pitch > 0])
    
    # Extract pitch contour from target
    target_pitch, _ = librosa.piptrack(y=y_target, sr=sr_target)
    target_pitch_median = np.median(target_pitch[target_pitch > 0])
    
    # Calculate pitch shift factor
    pitch_shift_factor = 12 * np.log2(source_pitch_median / target_pitch_median)
    
    # Shift pitch of target audio
    y_shifted = librosa.effects.pitch_shift(y_target, sr=sr_target, n_steps=pitch_shift_factor)
    
    # Extract energy envelope from source
    source_energy = np.array([sum(abs(y_source[i:i+512]**2)) for i in range(0, len(y_source), 512)])
    source_energy_smooth = savgol_filter(source_energy, 15, 3)
    
    # Extract energy envelope from target
    target_energy = np.array([sum(abs(y_shifted[i:i+512]**2)) for i in range(0, len(y_shifted), 512)])
    target_energy_smooth = savgol_filter(target_energy, 15, 3)
    
    # Calculate energy scaling factor
    energy_scaling = source_energy_smooth / (target_energy_smooth + 1e-10)
    energy_scaling = np.repeat(energy_scaling, 512)[:len(y_shifted)]
    
    # Apply energy scaling
    y_emotion_transferred = y_shifted * energy_scaling
    
    # Save the emotion-transferred audio
    sf.write(output_path, y_emotion_transferred, sr_target)
    
    return output_path