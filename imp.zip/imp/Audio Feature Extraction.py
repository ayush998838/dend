import librosa
import numpy as np

def extract_audio_features(audio_path, sr=16000):
    # Load audio
    y, sr = librosa.load(audio_path, sr=sr)
    
    # Extract MFCCs (Mel-frequency cepstral coefficients)
    mfccs = librosa.feature.mfcc(y=y, sr=sr, n_mfcc=13)
    
    # Extract pitch features
    pitches, magnitudes = librosa.piptrack(y=y, sr=sr)
    
    # Extract energy
    energy = np.array([
        sum(abs(y[i:i+512]**2)) 
        for i in range(0, len(y), 512)
    ])
    
    # Combine features
    features = {
        'mfccs': mfccs,
        'pitches': pitches,
        'magnitudes': magnitudes,
        'energy': energy
    }
    
    return features