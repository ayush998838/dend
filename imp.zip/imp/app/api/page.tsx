"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { AlertCircle, Upload, FileAudio, FileVideo, Languages, Wand2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function TranslationDashboard() {
  const [file, setFile] = useState<File | null>(null)
  const [fileType, setFileType] = useState<"audio" | "video" | null>(null)
  const [isProcessing, setIsProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [sourceLanguage, setSourceLanguage] = useState("")
  const [targetLanguage, setTargetLanguage] = useState("")
  const [preserveBackground, setPreserveBackground] = useState(true)
  const [result, setResult] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0]
      setFile(selectedFile)

      if (selectedFile.type.startsWith("audio/")) {
        setFileType("audio")
      } else if (selectedFile.type.startsWith("video/")) {
        setFileType("video")
      } else {
        setFileType(null)
      }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!file || !sourceLanguage || !targetLanguage) return

    setIsProcessing(true)
    setProgress(0)

    // Create form data
    const formData = new FormData()
    formData.append("file", file)
    formData.append("sourceLanguage", sourceLanguage)
    formData.append("targetLanguage", targetLanguage)
    formData.append("preserveBackground", preserveBackground.toString())

    try {
      // Simulate progress updates
      const progressInterval = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 95) {
            clearInterval(progressInterval)
            return prev
          }
          return prev + 5
        })
      }, 500)

      // Send to appropriate endpoint based on file type
      const endpoint = fileType === "audio" ? "/api/translate-audio" : "/api/translate-video"
      const response = await fetch(endpoint, {
        method: "POST",
        body: formData,
      })

      clearInterval(progressInterval)

      if (response.ok) {
        const data = await response.json()
        setResult(data.outputUrl)
        setProgress(100)
      } else {
        throw new Error("Translation failed")
      }
    } catch (error) {
      console.error("Error during translation:", error)
      setResult(null)
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold text-center mb-8">AI Audio/Video Translation</h1>

      <Tabs defaultValue="upload" className="max-w-3xl mx-auto">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upload">Upload</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>Upload Media for Translation</CardTitle>
              <CardDescription>
                Upload audio or video to translate while preserving voice, emotions, and timing.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <div className="grid w-full gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="file">Upload Audio or Video</Label>
                    <div
                      className="border-2 border-dashed rounded-lg p-10 text-center cursor-pointer hover:bg-slate-50 transition-colors"
                      onClick={() => document.getElementById("file")?.click()}
                    >
                      <Input
                        id="file"
                        type="file"
                        accept="audio/*,video/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                      <div className="flex flex-col items-center gap-2">
                        <Upload className="h-10 w-10 text-slate-400" />
                        {file ? (
                          <div>
                            <p className="font-medium">{file.name}</p>
                            <p className="text-sm text-slate-500">{(file.size / (1024 * 1024)).toFixed(2)} MB</p>
                          </div>
                        ) : (
                          <div>
                            <p className="font-medium">Click to upload or drag and drop</p>
                            <p className="text-sm text-slate-500">Audio (MP3, WAV) or Video (MP4, MOV)</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="sourceLanguage">Source Language</Label>
                      <Select value={sourceLanguage} onValueChange={setSourceLanguage}>
                        <SelectTrigger id="sourceLanguage">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Spanish</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                          <SelectItem value="de">German</SelectItem>
                          <SelectItem value="zh">Chinese</SelectItem>
                          <SelectItem value="ja">Japanese</SelectItem>
                          <SelectItem value="ko">Korean</SelectItem>
                          <SelectItem value="ru">Russian</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="targetLanguage">Target Language</Label>
                      <Select value={targetLanguage} onValueChange={setTargetLanguage}>
                        <SelectTrigger id="targetLanguage">
                          <SelectValue placeholder="Select language" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Spanish</SelectItem>
                          <SelectItem value="fr">French</SelectItem>
                          <SelectItem value="de">German</SelectItem>
                          <SelectItem value="zh">Chinese</SelectItem>
                          <SelectItem value="ja">Japanese</SelectItem>
                          <SelectItem value="ko">Korean</SelectItem>
                          <SelectItem value="ru">Russian</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {fileType === "audio" && (
                    <div className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id="preserveBackground"
                        checked={preserveBackground}
                        onChange={(e) => setPreserveBackground(e.target.checked)}
                        className="rounded border-gray-300"
                      />
                      <Label htmlFor="preserveBackground" className="cursor-pointer">
                        Preserve background music/sounds
                      </Label>
                    </div>
                  )}

                  {fileType === "video" && (
                    <Alert>
                      <AlertCircle className="h-4 w-4" />
                      <AlertTitle>Video Translation</AlertTitle>
                      <AlertDescription>
                        Video translation includes lip syncing to match the translated audio.
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button
                variant="outline"
                onClick={() => {
                  setFile(null)
                  setFileType(null)
                }}
              >
                Reset
              </Button>
              <Button onClick={handleSubmit} disabled={!file || !sourceLanguage || !targetLanguage || isProcessing}>
                {isProcessing ? "Processing..." : "Translate"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="results">
          <Card>
            <CardHeader>
              <CardTitle>Translation Results</CardTitle>
              <CardDescription>View and download your translated media.</CardDescription>
            </CardHeader>
            <CardContent>
              {isProcessing ? (
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <Wand2 className="animate-pulse h-6 w-6 text-purple-500" />
                    <div className="flex-1">
                      <p className="font-medium">Processing your translation</p>
                      <p className="text-sm text-slate-500">This may take a few minutes depending on file size</p>
                    </div>
                  </div>
                  <Progress value={progress} className="h-2" />
                  <div className="grid grid-cols-5 text-xs text-slate-500 mt-1">
                    <div>Speech Recognition</div>
                    <div>Translation</div>
                    <div>Voice Cloning</div>
                    <div>Synthesis</div>
                    <div>{fileType === "video" ? "Lip Syncing" : "Audio Merging"}</div>
                  </div>
                </div>
              ) : result ? (
                <div className="space-y-4">
                  <div className="bg-slate-50 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      {fileType === "audio" ? (
                        <FileAudio className="h-5 w-5 text-blue-500" />
                      ) : (
                        <FileVideo className="h-5 w-5 text-red-500" />
                      )}
                      <span className="font-medium">Translation Complete</span>
                    </div>

                    {fileType === "audio" ? (
                      <audio controls className="w-full mt-2">
                        <source src={result} type="audio/mpeg" />
                        Your browser does not support the audio element.
                      </audio>
                    ) : (
                      <video controls className="w-full mt-2 rounded">
                        <source src={result} type="video/mp4" />
                        Your browser does not support the video element.
                      </video>
                    )}
                  </div>

                  <div className="flex justify-end">
                    <Button asChild>
                      <a href={result} download>
                        Download
                      </a>
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-10">
                  <Languages className="h-10 w-10 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">No translations yet. Upload media to get started.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

