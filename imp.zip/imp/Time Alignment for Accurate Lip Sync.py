def align_audio_to_original_duration(original_audio_path, translated_audio_path, output_path):
    """
    Adjust the speed of the translated audio to match the duration of the original audio
    without changing the pitch.
    """
    import librosa
    import soundfile as sf
    import pyrubberband as pyrb
    
    # Load audio files
    y_orig, sr_orig = librosa.load(original_audio_path, sr=None)
    y_trans, sr_trans = librosa.load(translated_audio_path, sr=None)
    
    # Calculate durations
    duration_orig = librosa.get_duration(y=y_orig, sr=sr_orig)
    duration_trans = librosa.get_duration(y=y_trans, sr=sr_trans)
    
    # Calculate time stretch factor
    stretch_factor = duration_orig / duration_trans
    
    # Time-stretch the translated audio
    y_stretched = pyrb.time_stretch(y_trans, sr_trans, stretch_factor)
    
    # Save the time-stretched audio
    sf.write(output_path, y_stretched, sr_trans)
    
    return output_path