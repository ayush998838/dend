from flask import Blueprint, render_template, redirect, url_for, flash, request, session, current_app, jsonify
from flask_login import login_required, current_user
from functools import wraps
import logging
from app import db
from models import User, Translation, Language

# Set up logger
logger = logging.getLogger(__name__)

admin_bp = Blueprint('admin', __name__)

def admin_required(f):
    """
    Decorator that validates admin session before accessing protected routes.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Check if user has admin credentials in session
        if not session.get('admin_authenticated'):
            return redirect(url_for('admin.login'))
        return f(*args, **kwargs)
    return decorated_function

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    """
    Handle admin login.
    """
    if session.get('admin_authenticated'):
        return redirect(url_for('admin.dashboard'))
    
    if request.method == 'POST':
        access_key = request.form.get('access_key')
        
        if access_key == current_app.config['ADMIN_ACCESS_KEY']:
            session['admin_authenticated'] = True
            logger.info("Admin logged in")
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Invalid access key', 'danger')
    
    return render_template('admin/login.html', title='Admin Login')

@admin_bp.route('/logout')
@admin_required
def logout():
    """
    Handle admin logout.
    """
    session.pop('admin_authenticated', None)
    flash('You have been logged out of admin panel', 'info')
    return redirect(url_for('admin.login'))

@admin_bp.route('/')
@admin_required
def dashboard():
    """
    Admin dashboard showing system stats and controls.
    """
    # Get stats
    user_count = User.query.count()
    translation_count = Translation.query.count()
    
    # Get recent translations
    recent_translations = Translation.query.order_by(Translation.created_at.desc()).limit(10).all()
    
    # Calculate storage used
    total_storage = db.session.query(db.func.sum(User.storage_used)).scalar() or 0
    
    return render_template(
        'admin/dashboard.html',
        title='Admin Dashboard',
        user_count=user_count,
        translation_count=translation_count,
        recent_translations=recent_translations,
        total_storage=total_storage
    )

@admin_bp.route('/users')
@admin_required
def users():
    """
    User management page.
    """
    users = User.query.all()
    return render_template(
        'admin/users.html',
        title='User Management',
        users=users
    )

@admin_bp.route('/users/<int:user_id>')
@admin_required
def user_details(user_id):
    """
    View details of a specific user.
    """
    user = User.query.get_or_404(user_id)
    translations = Translation.query.filter_by(user_id=user_id).order_by(Translation.created_at.desc()).all()
    
    return render_template(
        'admin/user_details.html',
        title=f'User Details - {user.username}',
        user=user,
        translations=translations
    )

@admin_bp.route('/users/<int:user_id>/edit', methods=['GET', 'POST'])
@admin_required
def edit_user(user_id):
    """
    Edit a user's details.
    """
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        # Update user
        user.tier = request.form.get('tier')
        user.email_notifications = bool(request.form.get('email_notifications'))
        
        db.session.commit()
        flash('User updated successfully', 'success')
        return redirect(url_for('admin.user_details', user_id=user.id))
    
    return render_template(
        'admin/edit_user.html',
        title=f'Edit User - {user.username}',
        user=user
    )

@admin_bp.route('/translations')
@admin_required
def translations():
    """
    Translation management page.
    """
    translations = Translation.query.order_by(Translation.created_at.desc()).all()
    return render_template(
        'admin/translations.html',
        title='Translations Management',
        translations=translations
    )

@admin_bp.route('/translations/<int:translation_id>')
@admin_required
def translation_details(translation_id):
    """
    View details of a specific translation.
    """
    translation = Translation.query.get_or_404(translation_id)
    return render_template(
        'admin/translation_details.html',
        title=f'Translation Details - {translation.id}',
        translation=translation
    )

@admin_bp.route('/settings')
@admin_required
def system_settings():
    """
    System settings page.
    """
    languages = Language.query.all()
    return render_template(
        'admin/settings.html',
        title='System Settings',
        languages=languages
    )

@admin_bp.route('/maintenance')
@admin_required
def system_maintenance():
    """
    System maintenance page.
    """
    return render_template(
        'admin/maintenance.html',
        title='System Maintenance'
    )

# API Endpoints for admin panel

@admin_bp.route('/api/users/<int:user_id>/delete', methods=['POST'])
@admin_required
def api_delete_user(user_id):
    """
    API endpoint to delete a user.
    """
    user = User.query.get_or_404(user_id)
    db.session.delete(user)
    db.session.commit()
    
    return jsonify({'success': True, 'message': f'User {user.username} deleted successfully'})

@admin_bp.route('/api/translations/<int:translation_id>/delete', methods=['POST'])
@admin_required
def api_delete_translation(translation_id):
    """
    API endpoint to delete a translation.
    """
    translation = Translation.query.get_or_404(translation_id)
    
    # Delete the file
    try:
        output_dir = os.path.join(current_app.root_path, '../outputs')
        if translation.translated_filename:
            file_path = os.path.join(output_dir, translation.translated_filename)
            if os.path.exists(file_path):
                os.remove(file_path)
    except Exception as e:
        logger.error(f"Error deleting translation file: {e}")
    
    db.session.delete(translation)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Translation deleted successfully'})

@admin_bp.route('/api/stats', methods=['GET'])
@admin_required
def api_get_stats():
    """
    API endpoint to get system stats for dashboard.
    """
    user_count = User.query.count()
    translation_count = Translation.query.count()
    total_storage = db.session.query(db.func.sum(User.storage_used)).scalar() or 0
    
    # Get counts by status
    processing_count = Translation.query.filter_by(status='processing').count()
    completed_count = Translation.query.filter_by(status='completed').count()
    failed_count = Translation.query.filter_by(status='failed').count()
    
    return jsonify({
        'user_count': user_count,
        'translation_count': translation_count,
        'total_storage': round(total_storage, 2),
        'processing_count': processing_count,
        'completed_count': completed_count,
        'failed_count': failed_count
    })