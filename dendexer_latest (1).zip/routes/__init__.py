# Routes package initialization
# This makes the routes directory into a Python package