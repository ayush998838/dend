from flask import Blueprint, request, jsonify, current_app, send_from_directory
from flask_login import login_required, current_user
import os
import time
import json
from werkzeug.utils import secure_filename
import logging
import threading

# Set up logger
logger = logging.getLogger(__name__)

api_bp = Blueprint('api', __name__)

# Helper function to get the file handler
def get_file_handler():
    """
    Lazy-load the file handler to avoid circular imports
    """
    from utils.file_handler import FileHandler
    upload_folder = current_app.config['UPLOAD_FOLDER']
    output_folder = os.path.join(os.getcwd(), 'outputs')
    allowed_audio = current_app.config['ALLOWED_AUDIO_EXTENSIONS']
    allowed_video = current_app.config['ALLOWED_VIDEO_EXTENSIONS']
    
    return FileHandler(upload_folder, output_folder, allowed_audio, allowed_video)

@api_bp.route('/process', methods=['POST'])
@login_required
def process_file():
    """
    Process an uploaded audio or video file for translation.
    
    Expects form data with:
    - file: The audio/video file
    - source_language: Source language code
    - target_language: Target language code
    - file_type: "audio" or "video"
    - voice_profile_id: (optional) ID of voice profile to use
    - custom_voice_settings: (optional) JSON string with custom voice settings
    
    Returns JSON with:
    - success: Boolean indicating success
    - message: Status message
    - translation_id: ID of the created translation record
    """
    if 'file' not in request.files:
        return jsonify({
            'success': False,
            'message': 'No file part in the request'
        }), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({
            'success': False,
            'message': 'No file selected'
        }), 400
        
    source_language = request.form.get('source_language')
    target_language = request.form.get('target_language')
    file_type = request.form.get('file_type')
    voice_profile_id = request.form.get('voice_profile_id')
    custom_voice_settings = request.form.get('custom_voice_settings', '{}')
    
    try:
        voice_settings = json.loads(custom_voice_settings)
    except json.JSONDecodeError:
        voice_settings = {}
        
    # If voice profile ID is provided, load its settings
    if voice_profile_id:
        try:
            from models import VoiceProfile
            profile = VoiceProfile.query.get(voice_profile_id)
            if profile and profile.user_id == current_user.id:
                # Merge profile settings with any custom settings provided
                profile_settings = {
                    'pitch': profile.pitch,
                    'speed': profile.speed,
                    'emotion': profile.emotion
                }
                if hasattr(profile, 'custom_parameters') and profile.custom_parameters:
                    profile_settings.update(profile.custom_parameters)
                
                # Apply voice profile settings, preserving any custom settings provided
                for key, value in profile_settings.items():
                    if key not in voice_settings:
                        voice_settings[key] = value
            else:
                return jsonify({
                    'success': False,
                    'message': 'Voice profile not found or access denied'
                }), 404
        except Exception as e:
            logger.error(f"Error loading voice profile: {e}")
    
    try:
        # Save the uploaded file
        file_handler = get_file_handler()
        
        if not file_handler.allowed_file(file.filename, file_type):
            return jsonify({
                'success': False,
                'message': f"File type not allowed for {file_type}"
            }), 400
            
        file_path = file_handler.save_uploaded_file(file, file_type)
        
        # Get file size in megabytes
        file_size = os.path.getsize(file_path) / (1024 * 1024)
        
        # Create a translation record in the database
        from app import db
        from models import Translation
        
        # Create with 'processing' status
        translation = Translation(
            user_id=current_user.id,
            source_language=source_language,
            target_language=target_language,
            original_filename=secure_filename(file.filename),
            translated_filename='',  # Will be updated once processing is complete
            file_type=file_type,
            status='processing',
            progress=0,
            processing_steps=[],
            file_size=file_size,
            voice_settings=voice_settings
        )
        
        # Set expiration date (e.g., 30 days from now for free tier)
        from datetime import datetime, timedelta
        if current_user.tier == 'free':
            translation.expires_at = datetime.utcnow() + timedelta(days=30)
        elif current_user.tier == 'premium':
            translation.expires_at = datetime.utcnow() + timedelta(days=90)
        
        db.session.add(translation)
        db.session.commit()
        
        # Start processing in a background thread
        if file_type == 'audio':
            thread = threading.Thread(
                target=process_audio_file_background,
                args=(file_path, source_language, target_language, translation.id, voice_settings)
            )
        else:
            thread = threading.Thread(
                target=process_video_file_background,
                args=(file_path, source_language, target_language, translation.id, voice_settings)
            )
            
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True,
            'message': 'File uploaded and processing started',
            'translation_id': translation.id
        })
        
    except Exception as e:
        logger.error(f"Error processing file: {e}")
        return jsonify({
            'success': False,
            'message': f'Error processing file: {str(e)}'
        }), 500

def process_audio_file_background(file_path, source_language, target_language, translation_id, voice_settings=None):
    """
    Process an audio file for translation in the background.
    
    Args:
        file_path: Path to the audio file
        source_language: Source language code
        target_language: Target language code
        translation_id: ID of the translation record
        voice_settings: Voice customization settings
    """
    from app import db
    from models import Translation, User
    
    try:
        # Get the translation record
        with current_app.app_context():
            translation = Translation.query.get(translation_id)
            if not translation:
                logger.error(f"Translation record not found: {translation_id}")
                return
            
            # Update progress to indicate we're starting
            translation.progress = 5
            translation.processing_steps.append("Started audio processing")
            db.session.commit()
            
            # Import required modules
            from utils.audio_processor import AudioProcessor
            from utils.speech_recognition import SpeechRecognizer
            from utils.translation import Translator
            from utils.speech_synthesis import SpeechSynthesizer
            
            logger.info(f"Processing audio file: {file_path}")
            
            # Initialize components
            output_folder = os.path.join(os.getcwd(), 'outputs')
            audio_processor = AudioProcessor(current_app.config['UPLOAD_FOLDER'], output_folder)
            speech_recognizer = SpeechRecognizer()
            translator = Translator()
            speech_synthesizer = SpeechSynthesizer(output_folder)
            
            # Preprocess audio
            translation.progress = 10
            translation.processing_steps.append("Preprocessing audio")
            db.session.commit()
            
            processed_audio = audio_processor.preprocess_audio(file_path)
            logger.info("Audio preprocessing completed")
            
            # Separate vocals from background (if applicable)
            translation.progress = 20
            translation.processing_steps.append("Separating vocals from background")
            db.session.commit()
            
            vocals_path, background_path = audio_processor.separate_vocals(processed_audio)
            logger.info("Vocal separation completed")
            
            # Transcribe speech
            translation.progress = 30
            translation.processing_steps.append("Transcribing speech")
            db.session.commit()
            
            transcript = speech_recognizer.transcribe(vocals_path, source_language)
            logger.info("Transcription completed")
            
            # Translate content
            translation.progress = 50
            translation.processing_steps.append("Translating content")
            db.session.commit()
            
            translated_text = translator.translate(transcript, source_language, target_language)
            logger.info("Translation completed")
            
            # Apply voice settings if provided
            if voice_settings:
                for key, value in voice_settings.items():
                    logger.info(f"Applying voice setting: {key}={value}")
                    
            # Synthesize speech
            translation.progress = 70
            translation.processing_steps.append("Synthesizing speech")
            db.session.commit()
            
            synthesized_audio_path = speech_synthesizer.synthesize(
                translated_text, 
                target_language,
                voice_settings
            )
            logger.info("Speech synthesis completed")
            
            # Time-align the synthesized audio with the original
            translation.progress = 80
            translation.processing_steps.append("Time-aligning audio")
            db.session.commit()
            
            aligned_audio = audio_processor.time_align_audio(vocals_path, synthesized_audio_path)
            logger.info("Time alignment completed")
            
            # Merge with background
            translation.progress = 90
            translation.processing_steps.append("Merging with background audio")
            db.session.commit()
            
            if background_path:
                result_path = audio_processor.merge_audio(aligned_audio, background_path)
                logger.info("Audio merging completed")
            else:
                result_path = aligned_audio
            
            # Calculate duration of the audio file
            import subprocess
            result = subprocess.run(
                ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', result_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            try:
                duration = float(result.stdout.strip())
            except (ValueError, TypeError):
                duration = 0
                
            # Get the filename from the result path
            result_filename = os.path.basename(result_path)
            
            # Update the translation record
            translation.translated_filename = result_filename
            translation.status = 'completed'
            translation.progress = 100
            translation.processing_steps.append("Processing completed")
            translation.duration = duration
            
            # Update user's usage metrics
            user = User.query.get(translation.user_id)
            if user:
                user.translation_minutes += duration / 60  # Convert seconds to minutes
                user.storage_used += translation.file_size  # Add the file size in MB
            
            db.session.commit()
            
            logger.info(f"Translation completed successfully: {translation_id}")
            
    except Exception as e:
        logger.error(f"Error in audio processing: {e}")
        
        # Update the translation record with error information
        with current_app.app_context():
            translation = Translation.query.get(translation_id)
            if translation:
                translation.status = 'failed'
                translation.error_message = str(e)
                db.session.commit()
                
        raise

def process_video_file_background(file_path, source_language, target_language, translation_id, voice_settings=None):
    """
    Process a video file for translation with lip syncing in the background.
    
    Args:
        file_path: Path to the video file
        source_language: Source language code
        target_language: Target language code
        translation_id: ID of the translation record
        voice_settings: Voice customization settings
    """
    from app import db
    from models import Translation, User
    
    try:
        # Get the translation record
        with current_app.app_context():
            translation = Translation.query.get(translation_id)
            if not translation:
                logger.error(f"Translation record not found: {translation_id}")
                return
            
            # Update progress to indicate we're starting
            translation.progress = 5
            translation.processing_steps.append("Started video processing")
            db.session.commit()
            
            # Import required modules
            from utils.audio_processor import AudioProcessor
            from utils.speech_recognition import SpeechRecognizer
            from utils.translation import Translator
            from utils.speech_synthesis import SpeechSynthesizer
            from utils.video_processor import VideoProcessor
            import tempfile
            import subprocess
            
            logger.info(f"Processing video file: {file_path}")
            
            # Initialize components
            output_folder = os.path.join(os.getcwd(), 'outputs')
            audio_processor = AudioProcessor(current_app.config['UPLOAD_FOLDER'], output_folder)
            speech_recognizer = SpeechRecognizer()
            translator = Translator()
            speech_synthesizer = SpeechSynthesizer(output_folder)
            video_processor = VideoProcessor(output_folder)
            
            # Extract audio from video
            translation.progress = 10
            translation.processing_steps.append("Extracting audio from video")
            db.session.commit()
            
            temp_audio_path = os.path.join(tempfile.gettempdir(), f"{time.time()}_audio.wav")
            subprocess.run(['ffmpeg', '-i', file_path, '-q:a', '0', '-map', 'a', temp_audio_path, '-y'], check=True)
            logger.info("Audio extracted from video")
            
            # Process audio
            translation.progress = 20
            translation.processing_steps.append("Processing audio")
            db.session.commit()
            
            processed_audio = audio_processor.preprocess_audio(temp_audio_path)
            
            # Transcribe speech
            translation.progress = 30
            translation.processing_steps.append("Transcribing speech")
            db.session.commit()
            
            transcript = speech_recognizer.transcribe(processed_audio, source_language)
            logger.info("Transcription completed")
            
            # Translate content
            translation.progress = 50
            translation.processing_steps.append("Translating content")
            db.session.commit()
            
            translated_text = translator.translate(transcript, source_language, target_language)
            logger.info("Translation completed")
            
            # Apply voice settings if provided
            if voice_settings:
                for key, value in voice_settings.items():
                    logger.info(f"Applying voice setting: {key}={value}")
            
            # Synthesize translated speech
            translation.progress = 60
            translation.processing_steps.append("Synthesizing speech")
            db.session.commit()
            
            synthesized_audio_path = speech_synthesizer.synthesize(
                translated_text, 
                target_language,
                voice_settings
            )
            logger.info("Speech synthesis completed")
            
            # Time-align the synthesized audio
            translation.progress = 70
            translation.processing_steps.append("Time-aligning audio")
            db.session.commit()
            
            aligned_audio = audio_processor.time_align_audio(processed_audio, synthesized_audio_path)
            logger.info("Time alignment completed")
            
            # Process video for lip sync
            translation.progress = 80
            translation.processing_steps.append("Processing video with lip sync")
            db.session.commit()
            
            result_path = video_processor.process_video(file_path, aligned_audio)
            logger.info("Video processing completed")
            
            # Calculate duration of the video file
            import subprocess
            result = subprocess.run(
                ['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', result_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            try:
                duration = float(result.stdout.strip())
            except (ValueError, TypeError):
                duration = 0
                
            # Get the filename from the result path
            result_filename = os.path.basename(result_path)
            
            # Update the translation record
            translation.translated_filename = result_filename
            translation.status = 'completed'
            translation.progress = 100
            translation.processing_steps.append("Processing completed")
            translation.duration = duration
            
            # Update user's usage metrics
            user = User.query.get(translation.user_id)
            if user:
                user.translation_minutes += duration / 60  # Convert seconds to minutes
                user.storage_used += translation.file_size  # Add the file size in MB
            
            db.session.commit()
            
            logger.info(f"Video translation completed successfully: {translation_id}")
            
    except Exception as e:
        logger.error(f"Error in video processing: {e}")
        
        # Update the translation record with error information
        with current_app.app_context():
            translation = Translation.query.get(translation_id)
            if translation:
                translation.status = 'failed'
                translation.error_message = str(e)
                db.session.commit()
                
        raise

@api_bp.route('/translation/<int:translation_id>/status', methods=['GET'])
@login_required
def get_translation_status(translation_id):
    """
    Get the status of a translation job.
    
    Args:
        translation_id: ID of the translation job
        
    Returns:
        JSON with translation status information including progress percentage and processing steps
    """
    translation = Translation.query.get_or_404(translation_id)
    
    # Ensure user can only access their own translations
    if translation.user_id != current_user.id:
        return jsonify({
            'success': False,
            'message': 'Access denied'
        }), 403
    
    return jsonify({
        'success': True,
        'translation_id': translation.id,
        'status': translation.status,
        'progress': translation.progress,
        'steps': translation.processing_steps,
        'error': translation.error_message
    })

@api_bp.route('/download/<filename>', methods=['GET'])
@login_required
def download_file(filename):
    """
    Download a processed file.
    
    Args:
        filename: Name of the file to download
        
    Returns:
        File as attachment
    """
    # Ensure user can only download their own files
    translation = Translation.query.filter_by(
        translated_filename=filename, 
        user_id=current_user.id
    ).first()
    
    if not translation:
        return jsonify({
            'success': False,
            'message': 'File not found or access denied'
        }), 404
    
    return send_from_directory(
        os.path.join(os.getcwd(), 'outputs'),
        filename,
        as_attachment=True
    )

@api_bp.route('/voice-profile', methods=['POST'])
@login_required
def create_voice_profile():
    """
    Create a new voice profile.
    
    Expects JSON with:
    - name: Name of the profile
    - pitch: Voice pitch (optional, default 1.0)
    - speed: Voice speed (optional, default 1.0)
    - emotion: Voice emotion (optional, default 'neutral')
    - custom_parameters: JSON object with custom parameters (optional)
    
    Returns:
        JSON with the created profile information
    """
    data = request.get_json()
    
    try:
        from app import db
        from models import VoiceProfile
        
        profile = VoiceProfile(
            user_id=current_user.id,
            name=data.get('name'),
            pitch=data.get('pitch', 1.0),
            speed=data.get('speed', 1.0),
            emotion=data.get('emotion', 'neutral'),
            custom_parameters=data.get('custom_parameters', {})
        )
        
        db.session.add(profile)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'profile_id': profile.id,
            'message': 'Voice profile created successfully'
        })
        
    except Exception as e:
        logger.error(f"Error creating voice profile: {e}")
        return jsonify({
            'success': False,
            'message': f'Error creating voice profile: {str(e)}'
        }), 500

@api_bp.route('/voice-profile/<int:profile_id>', methods=['PUT'])
@login_required
def update_voice_profile(profile_id):
    """
    Update an existing voice profile.
    
    Args:
        profile_id: ID of the voice profile to update
        
    Expects JSON with parameters to update
    
    Returns:
        JSON with the updated profile information
    """
    data = request.get_json()
    
    try:
        from app import db
        from models import VoiceProfile
        
        profile = VoiceProfile.query.get_or_404(profile_id)
        
        # Ensure user can only update their own profiles
        if profile.user_id != current_user.id:
            return jsonify({
                'success': False,
                'message': 'Access denied'
            }), 403
        
        # Update fields
        if 'name' in data:
            profile.name = data['name']
        if 'pitch' in data:
            profile.pitch = data['pitch']
        if 'speed' in data:
            profile.speed = data['speed']
        if 'emotion' in data:
            profile.emotion = data['emotion']
        if 'custom_parameters' in data:
            profile.custom_parameters = data['custom_parameters']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Voice profile updated successfully'
        })
        
    except Exception as e:
        logger.error(f"Error updating voice profile: {e}")
        return jsonify({
            'success': False,
            'message': f'Error updating voice profile: {str(e)}'
        }), 500

@api_bp.route('/voice-profile/<int:profile_id>', methods=['DELETE'])
@login_required
def delete_voice_profile(profile_id):
    """
    Delete a voice profile.
    
    Args:
        profile_id: ID of the voice profile to delete
        
    Returns:
        JSON indicating success
    """
    try:
        from app import db
        from models import VoiceProfile
        
        profile = VoiceProfile.query.get_or_404(profile_id)
        
        # Ensure user can only delete their own profiles
        if profile.user_id != current_user.id:
            return jsonify({
                'success': False,
                'message': 'Access denied'
            }), 403
        
        db.session.delete(profile)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Voice profile deleted successfully'
        })
        
    except Exception as e:
        logger.error(f"Error deleting voice profile: {e}")
        return jsonify({
            'success': False,
            'message': f'Error deleting voice profile: {str(e)}'
        }), 500

@api_bp.route('/language-pairs', methods=['GET'])
@login_required
def get_language_pairs():
    """
    Get the user's language pairs.
    
    Returns:
        JSON with the user's language pairs
    """
    try:
        from models import LanguagePair
        
        pairs = LanguagePair.query.filter_by(user_id=current_user.id).all()
        
        pairs_data = [{
            'id': pair.id,
            'source_language': pair.source_language,
            'target_language': pair.target_language,
            'use_count': pair.use_count,
            'is_favorite': pair.is_favorite
        } for pair in pairs]
        
        return jsonify({
            'success': True,
            'pairs': pairs_data
        })
        
    except Exception as e:
        logger.error(f"Error getting language pairs: {e}")
        return jsonify({
            'success': False,
            'message': f'Error getting language pairs: {str(e)}'
        }), 500

@api_bp.route('/user/preferences', methods=['PUT'])
@login_required
def update_user_preferences():
    """
    Update user preferences.
    
    Expects JSON with:
    - email_notifications: Boolean indicating email notification preference
    - preferences: JSON object with additional preferences
    
    Returns:
        JSON indicating success
    """
    data = request.get_json()
    
    try:
        from app import db
        
        # Update user preferences
        if 'email_notifications' in data:
            current_user.email_notifications = data['email_notifications']
        
        if 'preferences' in data:
            current_user.preferences = data['preferences']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'User preferences updated successfully'
        })
        
    except Exception as e:
        logger.error(f"Error updating user preferences: {e}")
        return jsonify({
            'success': False,
            'message': f'Error updating user preferences: {str(e)}'
        }), 500

@api_bp.route('/user/account', methods=['PUT'])
@login_required
def update_user_account():
    """
    Update user account information.
    
    Expects JSON with:
    - email: Updated email address (optional)
    - new_password: New password (optional)
    
    Returns:
        JSON indicating success
    """
    data = request.get_json()
    
    try:
        from app import db
        from werkzeug.security import generate_password_hash
        
        # Update email if provided
        if 'email' in data and data['email'] != current_user.email:
            # Check if email is already in use
            from models import User
            if User.query.filter_by(email=data['email']).first():
                return jsonify({
                    'success': False,
                    'message': 'Email address already in use'
                }), 400
                
            current_user.email = data['email']
        
        # Update password if provided
        if 'new_password' in data and data['new_password']:
            current_user.password_hash = generate_password_hash(data['new_password'])
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Account information updated successfully'
        })
        
    except Exception as e:
        logger.error(f"Error updating user account: {e}")
        return jsonify({
            'success': False,
            'message': f'Error updating user account: {str(e)}'
        }), 500