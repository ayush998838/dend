from flask import Blueprint, render_template, redirect, url_for, send_from_directory, current_app
from flask_login import login_required, current_user
import os
import logging
from models import Language, Translation, LanguagePair

# Set up logger
logger = logging.getLogger(__name__)

web_bp = Blueprint('web', __name__)

@web_bp.route('/')
def index():
    """Render the landing page or redirect to main app if logged in."""
    if current_user.is_authenticated:
        return redirect(url_for('web.app_dashboard'))
    return render_template('index.html', title='Welcome to DenDexer')

@web_bp.route('/app')
@login_required
def app_dashboard():
    """Render the main application page (protected)."""
    languages = Language.query.all()
    recent_translations = Translation.query.filter_by(user_id=current_user.id).order_by(Translation.created_at.desc()).limit(5).all()
    voice_profiles = current_user.voice_profiles.all()
    
    return render_template(
        'dashboard.html',
        title='DenDexer Dashboard',
        languages=languages,
        recent_translations=recent_translations,
        voice_profiles=voice_profiles
    )

@web_bp.route('/settings')
@login_required
def user_settings():
    """Render the user settings page."""
    voice_profiles = current_user.voice_profiles.all()
    language_pairs = current_user.language_pairs.order_by(LanguagePair.is_favorite.desc(), LanguagePair.use_count.desc()).all()
    
    return render_template(
        'user_settings.html',
        title='Settings',
        voice_profiles=voice_profiles,
        language_pairs=language_pairs
    )

@web_bp.route('/output/<filename>')
@login_required
def serve_output(filename):
    """
    Serve output files for preview.
    
    Args:
        filename: Name of the file to serve
        
    Returns:
        File to be played/displayed in the browser
    """
    # Check if the file belongs to the current user
    translation = Translation.query.filter_by(
        translated_filename=filename, 
        user_id=current_user.id
    ).first()
    
    if not translation:
        return "File not found or access denied", 404
        
    output_dir = os.path.join(current_app.root_path, '../outputs')
    return send_from_directory(output_dir, filename)

@web_bp.route('/about')
def about():
    """Render the about page."""
    return render_template('about.html', title='About DenDexer')

# Register error handlers
web_bp.errorhandler(404)(lambda e: (render_template('errors/404.html', title='Page Not Found'), 404))
web_bp.errorhandler(500)(lambda e: (render_template('errors/500.html', title='Server Error'), 500))

# Create a dictionary for app to access error handlers
web_bp.handlers = {
    404: lambda e: (render_template('errors/404.html', title='Page Not Found'), 404),
    500: lambda e: (render_template('errors/500.html', title='Server Error'), 500)
}