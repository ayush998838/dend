import os
import logging
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager

# Load environment variables from .env file if present
try:
    from dotenv import load_dotenv
    load_dotenv()
    logger = logging.getLogger(__name__)
    logger.info("Loaded environment variables from .env file")
except ImportError:
    # If python-dotenv is not installed, try to load from .env.py
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location(".env", ".env.py")
        if spec and spec.loader:
            env_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(env_module)
            logger = logging.getLogger(__name__)
            logger.info("Loaded environment variables from .env.py file")
    except Exception as e:
        print(f"Note: Environment variables not loaded from file. Error: {e}")
        print("Make sure to set environment variables manually or create a .env file.")

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create base class for SQLAlchemy models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the Base class
db = SQLAlchemy(model_class=Base)

# Initialize LoginManager
login_manager = LoginManager()
login_manager.login_view = 'auth.login'
login_manager.login_message = 'Please log in to access this page.'
login_manager.login_message_category = 'info'

def create_app():
    # Create Flask app
    app = Flask(__name__)
    
    # Configure app
    app.secret_key = os.environ.get("SESSION_SECRET", "dev-key-for-testing")
    app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
    app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
        'pool_recycle': 300,
        'pool_pre_ping': True,
    }
    
    # Set up media configuration
    app.config['UPLOAD_FOLDER'] = os.path.join(os.getcwd(), 'uploads')
    app.config['ALLOWED_AUDIO_EXTENSIONS'] = {'mp3', 'wav', 'ogg', 'flac', 'm4a'}
    app.config['ALLOWED_VIDEO_EXTENSIONS'] = {'mp4', 'mov', 'avi', 'mkv', 'webm'}
    app.config['MAX_CONTENT_LENGTH'] = 1000 * 1024 * 1024  # 1000MB (1GB) max file size
    
    # Admin settings
    app.config['ADMIN_ACCESS_KEY'] = os.environ.get('ADMIN_ACCESS_KEY', 'admin-dev-key')
    
    # Create upload and output directories if they don't exist
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(os.path.join(os.getcwd(), 'outputs'), exist_ok=True)
    
    # Initialize extensions with app
    db.init_app(app)
    login_manager.init_app(app)
    
    # Import and register blueprints
    from routes.web import web_bp
    from routes.auth import auth_bp
    from routes.api import api_bp
    from routes.admin import admin_bp
    
    app.register_blueprint(web_bp)
    app.register_blueprint(auth_bp, url_prefix='/auth')
    app.register_blueprint(api_bp, url_prefix='/api')
    app.register_blueprint(admin_bp, url_prefix='/admin')
    
    # Register error handlers from web blueprint
    app.register_error_handler(404, web_bp.handlers[404])
    app.register_error_handler(500, web_bp.handlers[500])
    
    # Create database tables
    with app.app_context():
        db.create_all()
        
        # Initialize languages in the database if table exists and is empty
        from models import Language
        from sqlalchemy import inspect
        inspector = inspect(db.engine)
        if 'language' in inspector.get_table_names() and Language.query.count() == 0:
            languages = [
                {'code': 'en', 'name': 'English', 'voice_supported': True},
                {'code': 'es', 'name': 'Spanish', 'voice_supported': True},
                {'code': 'fr', 'name': 'French', 'voice_supported': True},
                {'code': 'de', 'name': 'German', 'voice_supported': True},
                {'code': 'it', 'name': 'Italian', 'voice_supported': True},
                {'code': 'pt', 'name': 'Portuguese', 'voice_supported': True},
                {'code': 'ru', 'name': 'Russian', 'voice_supported': True},
                {'code': 'zh', 'name': 'Chinese', 'voice_supported': True},
                {'code': 'ja', 'name': 'Japanese', 'voice_supported': True},
                {'code': 'ko', 'name': 'Korean', 'voice_supported': True},
                {'code': 'ar', 'name': 'Arabic', 'voice_supported': True},
                {'code': 'hi', 'name': 'Hindi', 'voice_supported': True},
                {'code': 'tr', 'name': 'Turkish', 'voice_supported': True},
                {'code': 'nl', 'name': 'Dutch', 'voice_supported': True},
                {'code': 'pl', 'name': 'Polish', 'voice_supported': True},
                {'code': 'sv', 'name': 'Swedish', 'voice_supported': True}
            ]
            
            for lang in languages:
                db.session.add(Language(**lang))
            
            db.session.commit()
            logger.info("Languages initialized in the database")
    
    return app

# User loader for flask-login
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Create app instance
app = create_app()