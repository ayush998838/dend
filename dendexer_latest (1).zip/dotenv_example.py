"""
Example script for loading environment variables in a local development setup.
Save as '.env.py' and run before starting the application.
"""
import os

# Database configuration (for local testing with SQLite)
os.environ['DATABASE_URL'] = 'sqlite:///dendexer.db'

# For PostgreSQL use:
# os.environ['DATABASE_URL'] = 'postgresql://username:password@localhost:5432/dendexer_db'

# Session secret key
os.environ['SESSION_SECRET'] = 'your-secret-key-change-this-in-production'

# OpenAI API Key (if using OpenAI services)
# os.environ['OPENAI_API_KEY'] = 'your-openai-api-key'

# Admin access key (for admin panel)
os.environ['ADMIN_ACCESS_KEY'] = 'admin-dev-key'

print("Environment variables loaded successfully.")