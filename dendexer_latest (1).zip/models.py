from app import db
from flask_login import UserMixin
from datetime import datetime
import json

class User(UserMixin, db.Model):
    """
    User model for authentication and tracking translations.
    """
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Usage metrics
    translation_minutes = db.Column(db.Float, default=0.0)  # Total minutes of audio/video translated
    storage_used = db.Column(db.Float, default=0.0)  # Total storage used in MB
    tier = db.Column(db.String(20), default='free')  # 'free', 'premium', 'enterprise'
    
    # User preferences
    preferences = db.Column(db.JSON, default={})
    email_notifications = db.Column(db.Boolean, default=False)
    
    # Relationships
    translations = db.relationship('Translation', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    voice_profiles = db.relationship('VoiceProfile', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    language_pairs = db.relationship('LanguagePair', backref='user', lazy='dynamic', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<User {self.username}>'

class Translation(db.Model):
    """
    Model to store translation metadata and history.
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    source_language = db.Column(db.String(10), nullable=False)
    target_language = db.Column(db.String(10), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    translated_filename = db.Column(db.String(255), nullable=False)
    file_type = db.Column(db.String(10), nullable=False)  # 'audio' or 'video'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime)  # When the file will be deleted
    
    # Processing status
    status = db.Column(db.String(20), default='processing')  # 'processing', 'completed', 'failed'
    progress = db.Column(db.Integer, default=0)  # Progress percentage (0-100)
    processing_steps = db.Column(db.JSON, default=[])  # List of completed processing steps
    error_message = db.Column(db.String(255))  # Error message if status is 'failed'
    
    # File metadata
    file_size = db.Column(db.Float)  # Size in MB
    duration = db.Column(db.Float)  # Duration in seconds
    
    # Voice settings used for this translation
    voice_settings = db.Column(db.JSON, default={})
    
    def __repr__(self):
        return f'<Translation {self.id}: {self.source_language} to {self.target_language}>'

class Language(db.Model):
    """
    Model to store supported languages.
    """
    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(10), unique=True, nullable=False)
    name = db.Column(db.String(50), nullable=False)
    voice_supported = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<Language {self.code} ({self.name})>'

class VoiceProfile(db.Model):
    """
    Model to store user's voice customization profiles.
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    name = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Voice parameters
    pitch = db.Column(db.Float, default=1.0)
    speed = db.Column(db.Float, default=1.0)
    emotion = db.Column(db.String(50), default='neutral')  # 'neutral', 'happy', 'sad', etc.
    custom_parameters = db.Column(db.JSON, default={})
    
    def __repr__(self):
        return f'<VoiceProfile {self.id}: {self.name}>'

class LanguagePair(db.Model):
    """
    Model to store user's frequent language pairs.
    """
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    source_language = db.Column(db.String(10), nullable=False)
    target_language = db.Column(db.String(10), nullable=False)
    use_count = db.Column(db.Integer, default=1)  # Number of times this pair has been used
    is_favorite = db.Column(db.Boolean, default=False)
    
    def __repr__(self):
        return f'<LanguagePair {self.source_language} to {self.target_language}>'