import os
import subprocess
import tempfile
import time
import logging
import numpy as np
from pydub import AudioSegment
import librosa
import soundfile as sf

logger = logging.getLogger(__name__)

class AudioProcessor:
    """
    Handles audio processing tasks for translation, including:
    - Audio preprocessing (normalization, noise reduction)
    - Vocal separation from background music/noise
    - Time alignment between original and translated audio
    - Audio merging with background music/sounds
    """
    
    def __init__(self, upload_folder, output_folder):
        """
        Initialize the AudioProcessor.
        
        Args:
            upload_folder: Directory with uploaded audio files
            output_folder: Directory for processed output files
        """
        self.upload_folder = upload_folder
        self.output_folder = output_folder
        
        # Create output directory if it doesn't exist
        os.makedirs(output_folder, exist_ok=True)
        
    def preprocess_audio(self, file_path):
        """
        Preprocess audio file for better quality.
        
        Args:
            file_path: Path to the audio file
            
        Returns:
            Path to the preprocessed audio file
        """
        logger.info(f"Preprocessing audio file: {file_path}")
        
        try:
            # Create a temporary file for processed audio
            output_path = os.path.join(tempfile.gettempdir(), f"{time.time()}_processed.wav")
            
            # Convert to WAV format at 16kHz, 16-bit, mono for better speech recognition
            subprocess.run([
                'ffmpeg', '-i', file_path, 
                '-ac', '1',               # Convert to mono
                '-ar', '16000',           # 16kHz sample rate
                '-acodec', 'pcm_s16le',   # 16-bit PCM
                '-af', 'loudnorm=I=-16:TP=-1.5:LRA=11', # Normalize loudness
                output_path, '-y'         # Output file (overwrite if exists)
            ], check=True)
            
            logger.info(f"Audio preprocessing completed: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error preprocessing audio: {e}")
            raise
    
    def separate_vocals(self, file_path):
        """
        Separate vocals from background music/noise.
        
        Args:
            file_path: Path to the audio file
            
        Returns:
            Tuple of (vocals_path, background_path)
        """
        logger.info(f"Separating vocals from background: {file_path}")
        
        # This is a simplified implementation
        # In a production setting, you'd use a dedicated source separation library like Spleeter
        try:
            # Generate output paths
            base_name = os.path.basename(file_path).split('.')[0]
            vocals_path = os.path.join(tempfile.gettempdir(), f"{base_name}_vocals.wav")
            background_path = os.path.join(tempfile.gettempdir(), f"{base_name}_background.wav")
            
            # The ideal implementation would use an ML model for source separation
            # For now, we'll use a simple high-pass filter to approximate vocals
            # This is just a placeholder - not effective for real use
            
            # Load audio
            y, sr = librosa.load(file_path, sr=None)
            
            # Apply a high-pass filter (crude approximation)
            # In a real implementation, use a proper source separation model
            vocals = librosa.effects.preemphasis(y)
            background = y - vocals
            
            # Normalize
            vocals = librosa.util.normalize(vocals)
            background = librosa.util.normalize(background)
            
            # Save the separated audio
            sf.write(vocals_path, vocals, sr)
            sf.write(background_path, background, sr)
            
            logger.info(f"Vocal separation completed")
            return vocals_path, background_path
            
        except Exception as e:
            logger.error(f"Error separating vocals: {e}")
            # If vocal separation fails, return original audio as vocals and None for background
            return file_path, None
    
    def time_align_audio(self, original_path, translated_path):
        """
        Time-align the translated audio with the original.
        
        Args:
            original_path: Path to the original audio file
            translated_path: Path to the translated audio file
            
        Returns:
            Path to the time-aligned audio file
        """
        logger.info(f"Time-aligning audio")
        
        try:
            # Create output path
            output_path = os.path.join(tempfile.gettempdir(), f"{time.time()}_aligned.wav")
            
            # Load audio files
            original, sr_orig = librosa.load(original_path, sr=None)
            translated, sr_trans = librosa.load(translated_path, sr=None)
            
            # Ensure same sample rate
            if sr_orig != sr_trans:
                translated = librosa.resample(translated, orig_sr=sr_trans, target_sr=sr_orig)
                sr_trans = sr_orig
            
            # Get durations
            duration_orig = librosa.get_duration(y=original, sr=sr_orig)
            duration_trans = librosa.get_duration(y=translated, sr=sr_trans)
            
            logger.info(f"Original duration: {duration_orig}s, Translated duration: {duration_trans}s")
            
            # If durations are already similar, no need for time stretching
            if abs(duration_orig - duration_trans) < 0.5:  # Less than 0.5 seconds difference
                logger.info("Durations already similar, skipping time alignment")
                sf.write(output_path, translated, sr_trans)
                return output_path
            
            # Time stretch the translated audio to match original duration
            stretch_factor = duration_orig / duration_trans
            logger.info(f"Stretching translated audio by factor: {stretch_factor}")
            
            # Simple time stretching
            # In a production setting, use a more sophisticated algorithm
            if stretch_factor > 0.5 and stretch_factor < 2.0:  # Reasonable range
                stretched = librosa.effects.time_stretch(translated, rate=stretch_factor)
                sf.write(output_path, stretched, sr_trans)
            else:
                # Fallback if stretch factor is extreme
                logger.warning(f"Stretch factor {stretch_factor} is extreme, using original timing")
                sf.write(output_path, translated, sr_trans)
            
            logger.info(f"Time alignment completed: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error time-aligning audio: {e}")
            # Return the translated audio unchanged if alignment fails
            return translated_path
    
    def merge_audio(self, vocals_path, background_path):
        """
        Merge the translated vocals with the background audio.
        
        Args:
            vocals_path: Path to the vocals audio file
            background_path: Path to the background audio file
            
        Returns:
            Path to the merged audio file
        """
        logger.info(f"Merging vocals with background")
        
        try:
            # Generate a unique output filename
            timestamp = int(time.time())
            output_filename = f"translated_{timestamp}.mp3"
            output_path = os.path.join(self.output_folder, output_filename)
            
            # Load audio files
            vocals = AudioSegment.from_file(vocals_path)
            background = AudioSegment.from_file(background_path)
            
            # Match durations
            if len(vocals) > len(background):
                # Extend background by looping if needed
                factor = (len(vocals) / len(background)) + 1
                background = background * int(factor)
                background = background[:len(vocals)]
            elif len(background) > len(vocals):
                # Trim background to match vocals
                background = background[:len(vocals)]
            
            # Mix vocals and background with vocals at higher volume
            # Adjust these values for better balance
            vocals = vocals + 2  # Make vocals slightly louder
            background = background - 6  # Make background quieter
            
            # Mix the audio
            mixed = vocals.overlay(background)
            
            # Export the final audio
            mixed.export(output_path, format="mp3", bitrate="192k")
            
            logger.info(f"Audio merging completed: {output_path}")
            return output_path
            
        except Exception as e:
            logger.error(f"Error merging audio: {e}")
            # Return just the vocals if merging fails
            try:
                # Generate a unique output filename
                timestamp = int(time.time())
                output_filename = f"translated_{timestamp}.mp3"
                output_path = os.path.join(self.output_folder, output_filename)
                
                # Copy vocals to output
                vocals = AudioSegment.from_file(vocals_path)
                vocals.export(output_path, format="mp3", bitrate="192k")
                
                return output_path
            except:
                # Last resort fallback
                return vocals_path