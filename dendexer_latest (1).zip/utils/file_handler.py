import os
import time
from werkzeug.utils import secure_filename
import logging

logger = logging.getLogger(__name__)

class FileHandler:
    """
    Utility class for handling file operations in the application.
    
    This class manages file uploads, validation, and cleanup operations.
    """
    
    def __init__(self, upload_folder, output_folder, allowed_audio=None, allowed_video=None):
        """
        Initialize the FileHandler with the specified folders and allowed extensions.
        
        Args:
            upload_folder: Directory for storing uploaded files
            output_folder: Directory for storing processed output files
            allowed_audio: Set of allowed audio file extensions
            allowed_video: Set of allowed video file extensions
        """
        self.upload_folder = upload_folder
        self.output_folder = output_folder
        self.allowed_audio = allowed_audio or {'mp3', 'wav', 'ogg', 'flac', 'm4a'}
        self.allowed_video = allowed_video or {'mp4', 'mov', 'avi', 'mkv', 'webm'}
        
        # Create directories if they don't exist
        os.makedirs(upload_folder, exist_ok=True)
        os.makedirs(output_folder, exist_ok=True)
    
    def allowed_file(self, filename, file_type):
        """
        Check if the file extension is allowed.
        
        Args:
            filename: Name of the file to check
            file_type: 'audio' or 'video'
            
        Returns:
            Boolean indicating if the file extension is allowed
        """
        if not filename or '.' not in filename:
            return False
            
        extension = filename.rsplit('.', 1)[1].lower()
        
        if file_type == 'audio':
            return extension in self.allowed_audio
        elif file_type == 'video':
            return extension in self.allowed_video
        else:
            return False
    
    def save_uploaded_file(self, file, file_type):
        """
        Save an uploaded file to the upload directory.
        
        Args:
            file: The file object from request.files
            file_type: 'audio' or 'video'
            
        Returns:
            Path to the saved file
        """
        if not self.allowed_file(file.filename, file_type):
            raise ValueError(f"File type not allowed for {file_type}")
            
        # Create a unique filename with timestamp to avoid collisions
        filename = secure_filename(file.filename)
        timestamp = int(time.time())
        unique_filename = f"{timestamp}_{filename}"
        
        # Save the file
        file_path = os.path.join(self.upload_folder, unique_filename)
        file.save(file_path)
        logger.info(f"Saved uploaded file to {file_path}")
        
        return file_path
    
    def cleanup_old_files(self, days=30):
        """
        Clean up files older than the specified number of days.
        
        Args:
            days: Number of days, files older than this will be deleted
            
        Returns:
            Number of files deleted
        """
        count = 0
        current_time = time.time()
        max_age = days * 24 * 60 * 60  # Convert days to seconds
        
        # Clean upload folder
        for filename in os.listdir(self.upload_folder):
            file_path = os.path.join(self.upload_folder, filename)
            if os.path.isfile(file_path):
                file_age = current_time - os.path.getmtime(file_path)
                if file_age > max_age:
                    os.remove(file_path)
                    count += 1
                    logger.info(f"Deleted old upload file: {file_path}")
        
        # Clean output folder
        for filename in os.listdir(self.output_folder):
            file_path = os.path.join(self.output_folder, filename)
            if os.path.isfile(file_path):
                file_age = current_time - os.path.getmtime(file_path)
                if file_age > max_age:
                    os.remove(file_path)
                    count += 1
                    logger.info(f"Deleted old output file: {file_path}")
        
        return count